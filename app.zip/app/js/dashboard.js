// ===============================
// GLOBAL STATE
// ===============================
let lastScrollY = 0;
const SCROLL_THRESHOLD = 40;
let selectedFile = null;
let currentBoardId = null;

// ===============================
// ELEMENTS
// ===============================
const storiesBar = document.getElementById('storiesBar');
const fab = document.querySelector('.fab');
const modal = document.getElementById('addModal');
const bottomNavButtons = document.querySelectorAll('.nav-btn');
const photoGrid = document.getElementById('photoGrid');
const membersBar = document.getElementById('membersBar');

// Upload elements
const uploadStep1 = document.getElementById('uploadStep1');
const uploadStep2 = document.getElementById('uploadStep2');
const uploadStep3 = document.getElementById('uploadStep3');
const photoInput = document.getElementById('photoInput');
const photoPreview = document.getElementById('photoPreview');
const captionInput = document.getElementById('captionInput');
const confirmUpload = document.getElementById('confirmUpload');
const cancelUpload = document.getElementById('cancelUpload');

// Boards elements
const navHome = document.getElementById('navHome');
const boardsPanel = document.getElementById('boardsPanel');
const boardsList = document.getElementById('boardsList');
const closeBoardsPanel = document.getElementById('closeBoardsPanel');
const newBoardTitle = document.getElementById('newBoardTitle');
const createBoardBtn = document.getElementById('createBoardBtn');

// ===============================
// INIT — Load saved board or show boards panel
// ===============================
document.addEventListener('DOMContentLoaded', () => {
    currentBoardId = sessionStorage.getItem('currentBoardId');

    if (currentBoardId) {
        currentBoardId = parseInt(currentBoardId);
        loadBoard();
    } else {
        // No board selected — open boards panel automatically
        openBoardsPanel();
    }
});

function loadBoard() {
    if (!currentBoardId) return;
    storiesBar.style.display = '';
    loadPhotos();
    loadBoardMembers();
}

// ===============================
// STORIES BAR HIDE / SHOW ON SCROLL
// ===============================
window.addEventListener('scroll', () => {
    const currentScrollY = window.scrollY;

    if (!storiesBar) return;

    if (currentScrollY > lastScrollY && currentScrollY > SCROLL_THRESHOLD) {
        storiesBar.style.transform = 'translateY(-110%)';
        storiesBar.style.opacity = '0';
    } else {
        storiesBar.style.transform = 'translateY(0)';
        storiesBar.style.opacity = '1';
    }

    lastScrollY = currentScrollY;
});

// ===============================
// BOARDS PANEL
// ===============================
if (navHome) {
    navHome.addEventListener('click', (e) => {
        e.stopPropagation();
        openBoardsPanel();
    });
}

if (closeBoardsPanel) {
    closeBoardsPanel.addEventListener('click', () => {
        closeBoardsPanelFn();
    });
}

if (boardsPanel) {
    boardsPanel.addEventListener('click', (e) => {
        if (e.target === boardsPanel) {
            closeBoardsPanelFn();
        }
    });
}

function openBoardsPanel() {
    loadBoardsList();
    boardsPanel.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeBoardsPanelFn() {
    boardsPanel.style.display = 'none';
    document.body.style.overflow = '';
}

function loadBoardsList() {
    boardsList.innerHTML = '<p class="boards-loading">Cargando...</p>';

    fetch('/app/api/get-boards.php')
        .then(res => res.json())
        .then(data => {
            boardsList.innerHTML = '';

            if (!data.boards || data.boards.length === 0) {
                boardsList.innerHTML = '<div class="boards-empty"><p>Aún no tienes tableros.</p><p>Crea tu primero para comenzar.</p></div>';
                return;
            }

            data.boards.forEach(board => {
                var el = document.createElement('button');
                el.className = 'board-item';
                if (currentBoardId && parseInt(board.id) === currentBoardId) {
                    el.classList.add('board-active');
                }
                el.innerHTML = '<span class="board-title">' + escapeHtml(board.title) + '</span>' +
                    '<span class="board-meta">' + board.member_count + ' miembro' + (board.member_count != 1 ? 's' : '') + '</span>';
                el.addEventListener('click', function() {
                    selectBoard(parseInt(board.id));
                });
                boardsList.appendChild(el);
            });
        })
        .catch(function() {
            boardsList.innerHTML = '<p class="boards-loading">Error al cargar tableros</p>';
        });
}

function selectBoard(boardId) {
    currentBoardId = boardId;
    sessionStorage.setItem('currentBoardId', boardId);
    closeBoardsPanelFn();
    loadBoard();
}

// Create board
if (createBoardBtn) {
    createBoardBtn.addEventListener('click', function() {
        var title = newBoardTitle.value.trim();
        if (!title) {
            newBoardTitle.focus();
            return;
        }

        createBoardBtn.disabled = true;

        var formData = new FormData();
        formData.append('title', title);

        fetch('/app/api/create-board.php', {
            method: 'POST',
            body: formData
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            createBoardBtn.disabled = false;
            if (data.success) {
                newBoardTitle.value = '';
                selectBoard(data.board_id);
            } else {
                alert(data.message || 'Error al crear el tablero');
            }
        })
        .catch(function() {
            createBoardBtn.disabled = false;
            alert('Error de conexión');
        });
    });
}

// ===============================
// MODAL OPEN / CLOSE (Photo upload)
// ===============================
if (fab && modal) {
    fab.addEventListener('click', () => {
        if (!currentBoardId) {
            openBoardsPanel();
            return;
        }
        openModal();
    });
}

if (modal) {
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });

    document.querySelectorAll('#addModal .close').forEach(btn => {
        btn.addEventListener('click', closeModal);
    });
}

function openModal() {
    resetUploadState();
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    modal.style.display = 'none';
    document.body.style.overflow = '';
    resetUploadState();
}

function resetUploadState() {
    selectedFile = null;
    if (photoInput) photoInput.value = '';
    if (captionInput) captionInput.value = '';
    if (uploadStep1) uploadStep1.style.display = '';
    if (uploadStep2) uploadStep2.style.display = 'none';
    if (uploadStep3) uploadStep3.style.display = 'none';
}

// ===============================
// PHOTO UPLOAD FLOW
// ===============================

// Step 1 -> Step 2: File selected
if (photoInput) {
    photoInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        selectedFile = file;

        const reader = new FileReader();
        reader.onload = (ev) => {
            photoPreview.src = ev.target.result;
            uploadStep1.style.display = 'none';
            uploadStep2.style.display = '';
        };
        reader.readAsDataURL(file);
    });
}

// Step 2 -> Back to Step 1
if (cancelUpload) {
    cancelUpload.addEventListener('click', (e) => {
        e.stopPropagation();
        resetUploadState();
    });
}

// Step 2 -> Step 3: Confirm upload
if (confirmUpload) {
    confirmUpload.addEventListener('click', () => {
        if (!selectedFile || !currentBoardId) return;

        uploadStep2.style.display = 'none';
        uploadStep3.style.display = '';

        const formData = new FormData();
        formData.append('photo', selectedFile);
        formData.append('caption', captionInput.value.trim());
        formData.append('board_id', currentBoardId);

        fetch('/app/api/upload-photo.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                closeModal();
                loadPhotos();
                loadBoardMembers();
            } else {
                alert(data.message || 'Error al subir la foto');
                resetUploadState();
            }
        })
        .catch(() => {
            alert('Error de conexión. Intenta de nuevo.');
            resetUploadState();
        });
    });
}

// ===============================
// BOTTOM NAV ACTIVE STATE
// ===============================
bottomNavButtons.forEach(button => {
    button.addEventListener('click', () => {
        bottomNavButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
    });
});

// ===============================
// LOAD PHOTOS FROM DATABASE
// ===============================
function loadPhotos() {
    if (!photoGrid || !currentBoardId) return;

    fetch('/app/api/get-photos.php?board_id=' + currentBoardId)
        .then(res => res.json())
        .then(data => {
            photoGrid.innerHTML = '';

            if (!data || data.length === 0) {
                renderFounderState();
                return;
            }

            data.forEach(photo => {
                const item = document.createElement('div');
                item.className = 'grid-item';

                item.innerHTML = '<img src="' + escapeHtml(photo.image_url) + '" alt="Foto del reto">' +
                    '<div class="rating-chip">' +
                    '<span class="star">&#11088;</span>' +
                    '<span class="rating-value">' + photo.rating + '</span>' +
                    '</div>';

                photoGrid.appendChild(item);
            });
        })
        .catch(() => {
            renderTechnicalError();
        });
}

// ===============================
// LOAD BOARD MEMBERS
// ===============================
function loadBoardMembers() {
    if (!membersBar || !currentBoardId) return;

    fetch('/app/api/get-board-members.php?board_id=' + currentBoardId)
        .then(res => res.json())
        .then(data => {
            membersBar.innerHTML = '';

            // Invite button (always first, far left)
            var inviteEl = document.createElement('div');
            inviteEl.className = 'story story-invite';
            inviteEl.innerHTML = '<span class="invite-icon">+</span>';
            inviteEl.addEventListener('click', function() {
                shareInviteLink(data.board_id);
            });
            membersBar.appendChild(inviteEl);

            // Members
            if (data.members && data.members.length > 0) {
                data.members.forEach(function(member) {
                    var el = document.createElement('div');
                    el.className = 'story';
                    var initials = getInitials(member.name);
                    el.innerHTML = '<span class="member-avatar">' + initials + '</span>';
                    el.title = member.name;
                    membersBar.appendChild(el);
                });
            }
        })
        .catch(function() {
            // Silently fail
        });
}

function getInitials(name) {
    if (!name) return '?';
    var parts = name.trim().split(' ');
    if (parts.length >= 2) {
        return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return parts[0].substring(0, 2).toUpperCase();
}

function shareInviteLink(boardId) {
    var link = window.location.origin + '/app/auth/register.php?board=' + (boardId || '');

    if (navigator.share) {
        navigator.share({
            title: 'Gatooso',
            text: 'Unite a mi tablero en Gatooso',
            url: link
        }).catch(function() {});
    } else {
        navigator.clipboard.writeText(link).then(function() {
            alert('Link de invitación copiado');
        }).catch(function() {
            prompt('Copia este link de invitación:', link);
        });
    }
}

// ===============================
// FOUNDER STATE (NO PHOTOS YET)
// ===============================
function renderFounderState() {
    photoGrid.innerHTML = '<div class="empty-state"><div class="empty-inner">' +
        '<h2>Este reto aún no tiene historia</h2>' +
        '<p>Atrévete a ser la primera persona que lo inicia. Los retos no empiezan solos. Empiezan con alguien como tú.</p>' +
        '<button class="empty-cta">Iniciar el reto</button>' +
        '</div></div>';

    var cta = document.querySelector('.empty-cta');
    if (cta && fab) {
        cta.addEventListener('click', function() { fab.click(); });
    }
}

// ===============================
// TECHNICAL ERROR STATE
// ===============================
function renderTechnicalError() {
    photoGrid.innerHTML = '<div class="empty-state"><div class="empty-inner">' +
        '<h2>Algo se nos cruzó</h2>' +
        '<p>No es tu culpa. Intenta de nuevo en un momento.</p>' +
        '</div></div>';
}

// ===============================
// UTILS
// ===============================
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ===============================
// SERVICE WORKER (PWA)
// ===============================
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/app/sw.js');
    });
}
